<?php
// error_reporting(0);
include('Connection.php');
if (isset($_POST['Start'])) {
  # code...

    if(isset($_POST['Right'])<>null){
          $right=$_POST['Right'];
          $action='right_1';
        $dir = $right;
    }

    if(isset($_POST['Left'])<>null)
    {
          $Left=$_POST['Left'];
          $action='left_2';
          $dir = $Left;
          

    }
    if(isset($_POST['Forward'])<>null)
    {
      
          $Forward=$_POST['Forward'];
          $action='forward_3';
          $dir = $Forward;

    }
  }
?>
<!DOCTYPE html>
<html>

<head>
  <link rel="stylesheet" href="Style.css">


  <link rel="icon" href="remote-control.png">
</head>

<header>
<h2 align="center">Welcome to The Robot Control</h2>
</header>

<nav>
<body>
<style>
.rotate90 {
    -webkit-transform: rotate(90deg);
    -moz-transform: rotate(90deg);
    -o-transform: rotate(90deg);
    -ms-transform: rotate(90deg);
    transform: rotate(90deg);
}
.rotate180 {
    -webkit-transform: rotate(180deg);
    -moz-transform: rotate(180deg);
    -o-transform: rotate(180deg);
    -ms-transform: rotate(180deg);
    transform: rotate(180deg);
}
</style>


<form style="display: inline-block;" action="" method=post>

<fieldset >
  <legend> Robot Control </legend>
  <label> Right : </label><br>
  <input type="number" id="Right" name="Right" ><br>
<br>
  <label for="lname">Forward :</label><br>
  <input type="number" id="Forward" name="Forward" ><br><br>

  <label for="lname">Left :</label><br>
  <input type="number" id="Left" name="Left"><br><br>
<pre>
<input name="Start" value="Start" type="submit"><input name="Save" value="Save" type="submit"><input name="Delete" value="Delete" type="submit">


</pre>
</fieldset>
</form>
<center>
<div style="display: inline-block;margin-right:50%;" id="mapArea">
  <fieldset style="width: 200%;height:200%;">
  <legend> Map Area </legend>
<p id = "map"></p>
<?php




  if(!isset($right)||$right=='')
  {
    $right=0;
  }
  else{
    $action='right_1';
    $dir = $right;
  }
  ?>                                                                                                                                                                                                                                                                                                                                                                                                                                                                        
  <img class="rotate180"  src="arrow.png" height="<?php echo $right;?>" >
  <?php



  if(!isset($Forward)||$Forward=='')
  {
    $Forward=0;
  }
  else{
    $action='forward_';
    $dir = $Forward;
  }
  ?>
  <img class="rotate90" src="arrow.png" height="<?php echo $Forward;?>" >
  <?php


  if(!isset($Left)||$Left=='')
  {
    $Left=0;
  }
  else{
    $action='left_2';
      $dir = $Left;
  }
  ?>
  <img  src="arrow.png" height="<?php echo $Left;?>" >
 
</fieldset>
</div>
</center>
<br>
<table style="width:50%" align="center">
  <tr>
    <th>Direction</th>
    <th>Input</th>
</tr>
<tr>
<?php
    $sql_f="SELECT * FROM `robot` ORDER BY `robot`.`id` DESC";
    $query_f=mysqli_query($conn,$sql_f);
    $result =mysqli_fetch_all($query_f,MYSQLI_ASSOC);
    $count=count($result);
    $i = 0;
    if ($query_f) {
      # code...
      // print_r($result);
      while ($i<$count) {
        $direction=$result[$i]['direction'];
        $value = $result[$i]['steps'];
        
        echo '<td>'.$direction.'</td><td>'. $value.'</tr>';
        $i++;
      }
    }
    ?>
    

    
  </tr>

</table>


<br><br>
</body>
</nav>
</html>
<?php
if (isset($_POST['Save'])) {
  if ($_POST['Right']<>null) {
    $go = 'right';
    $steps=$_POST['Right'];
  }
  if ($_POST['Forward']<>null) {
    $go = 'forward';
    $steps=$_POST['Forward'];

  }
  if ($_POST['left']<>null) {
    $go = 'left';
    $steps=$_POST['Left'];

  }
  
  $sql1="INSERT INTO `robot`(`direction`, `steps`) VALUES ('$go','$steps')";
  $query=mysqli_query($conn,$sql1);
  

}
if (isset($_POST['Delete'])) {

  if ($_POST['Right']<>null) {
    $go = 'right';
    $steps=$_POST['Right'];
  }
  if ($_POST['Forward']<>null) {
    $go = 'forward';
    $steps=$_POST['Forward'];

  }
  if ($_POST['left']<>null) {
    $go = 'left';
    $steps=$_POST['Left'];

  }

  $sql1="DELETE FROM `robot` WHERE (`direction`='$go' and `steps`='$steps') ";
  $query=mysqli_query($conn,$sql1);

}

?>

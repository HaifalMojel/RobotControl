<?php
$user = 'root';
$password = 'root';
$db = 'robot';
$host = 'localhost';
$conn= mysqli_connect($host,$user,$password,$db);



?>
